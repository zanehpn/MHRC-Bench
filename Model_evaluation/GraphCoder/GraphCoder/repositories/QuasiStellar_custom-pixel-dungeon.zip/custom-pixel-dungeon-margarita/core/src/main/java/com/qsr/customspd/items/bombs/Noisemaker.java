/*
 * Pixel Dungeon
 * Copyright (C) 2012-2015 Oleg Dolya
 *
 * Shattered Pixel Dungeon
 * Copyright (C) 2014-2023 Evan Debenham
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

package com.qsr.customspd.items.bombs;

import com.qsr.customspd.Assets;
import com.qsr.customspd.Dungeon;
import com.qsr.customspd.actors.Actor;
import com.qsr.customspd.actors.buffs.Buff;
import com.qsr.customspd.actors.hero.Hero;
import com.qsr.customspd.actors.mobs.Mob;
import com.qsr.customspd.effects.CellEmitter;
import com.qsr.customspd.effects.Speck;
import com.qsr.customspd.items.Heap;
import com.qsr.customspd.items.Item;
import com.qsr.customspd.assets.GeneralAsset;
import com.qsr.customspd.sprites.ItemSprite;
import com.watabou.noosa.audio.Sample;
import com.watabou.utils.Bundle;

public class Noisemaker extends Bomb {
	
	{
		image = GeneralAsset.NOISEMAKER;
	}

	public void setTrigger(int cell){

		Buff.affect(Dungeon.hero, Trigger.class).set(cell);
		fuse = null;

		CellEmitter.center( cell ).start( Speck.factory( Speck.SCREAM ), 0.3f, 3 );
		Sample.INSTANCE.play( Assets.Sounds.ALERT );

		for (Mob mob : Dungeon.level.mobs.toArray( new Mob[0] )) {
			mob.beckon( cell );
		}

	}

	@Override
	public ItemSprite.Glowing glowing() {
		if (fuse == null){
			for (Trigger trigger : Dungeon.hero.buffs(Trigger.class)){
				Heap heap = Dungeon.level.heaps.get(trigger.cell);
				if (heap != null && heap.items.contains(this)) {
					return new ItemSprite.Glowing( 0xFF0000, 0.6f);
				}
			}
		}
		return super.glowing();
	}

	@Override
	public boolean doPickUp(Hero hero, int pos) {
		if (fuse == null){
			for (Trigger trigger : hero.buffs(Trigger.class)){
				if (trigger.cell == pos) return false;
			}
		}
		return super.doPickUp(hero, pos);
	}

	public static class Trigger extends Buff {

		{
			revivePersists = true;
		}

		int cell;
		String floor;
		int left;
		
		public void set(int cell){
			floor = Dungeon.levelName;
			this.cell = cell;
			left = 6;
		}
		
		@Override
		public boolean act() {

			if (!Dungeon.levelName.equals(floor)){
				spend(TICK);
				return true;
			}

			Noisemaker bomb = null;
			Heap heap = Dungeon.level.heaps.get(cell);

			if (heap != null){
				for (Item i : heap.items){
					if (i instanceof Noisemaker){
						bomb = (Noisemaker) i;
						break;
					}
				}
			}

			if (bomb == null) {
				detach();

			} else if (Actor.findChar(cell) != null)  {

				heap.items.remove(bomb);
				if (heap.items.isEmpty()) {
					heap.destroy();
				}

				detach();
				bomb.explode(cell);

			} else {
				spend(TICK);

				left--;

				if (left <= 0){
					CellEmitter.center( cell ).start( Speck.factory( Speck.SCREAM ), 0.3f, 3 );
					Sample.INSTANCE.play( Assets.Sounds.ALERT );

					for (Mob mob : Dungeon.level.mobs.toArray( new Mob[0] )) {
						mob.beckon( cell );
					}
					left = 6;
				}

			}

			return true;
		}

		private static final String CELL = "cell";
		private static final String FLOOR = "floor";
		private static final String LEFT = "left";

		@Override
		public void storeInBundle(Bundle bundle) {
			super.storeInBundle(bundle);
			bundle.put(CELL, cell);
			bundle.put(FLOOR, floor);
			bundle.put(LEFT, left);
		}
		
		@Override
		public void restoreFromBundle(Bundle bundle) {
			super.restoreFromBundle(bundle);
			cell = bundle.getInt(CELL);
			floor = bundle.getString(FLOOR);
			left = bundle.getInt(LEFT);
		}
	}
	
	@Override
	public int value() {
		//prices of ingredients
		return quantity * (20 + 40);
	}
}
